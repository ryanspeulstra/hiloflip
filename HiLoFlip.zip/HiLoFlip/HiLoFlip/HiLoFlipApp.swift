//
//  HiLoFlipApp.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 9/13/24.
//

import SwiftUI

@main
struct HiLoFlipApp: App {
    @State var game = HiLoFlipCardGame(playerNames: ["Jeff", "Bob"])
    var body: some Scene {
        WindowGroup {
            GameView().environment(game)
        }
    }
}
