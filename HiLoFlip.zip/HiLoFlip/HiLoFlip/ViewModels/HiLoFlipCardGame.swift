//
//  HiLoFlipCardGame.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 9/30/24.
//

import Foundation
import SwiftUICore

@Observable
class HiLoFlipCardGame {
    var game: HiLoGame
    var players: [HiLoGame.Player] { game.players }
    var isTokenHi: Bool { game.isTokenHi }
    typealias Card = HiLoGame.Card

    
    init(playerNames: [String]) {
        self.game = HiLoGame(players: playerNames)
        }
    
    func resetGame() {
        game.resetGame()
    }
    
    func hand(forPlayer: HiLoGame.Player) -> [HiLoGame.Card] {
        return forPlayer.hand
        }
    
    var topDiscardCard: Card? {
        game.discardPile.first
    }
    
    func playCard(_ card: Card) {
        game.playCard(card)
    }
    
    // compiler took too long error? TODO
    func handSize(_ index: Int) -> Int {
        return players[index].hand.count
    }
    
    var playerNames: [String] {
        get { game.playerNames }
        set { game.playerNames = newValue }
    }
    
    }
