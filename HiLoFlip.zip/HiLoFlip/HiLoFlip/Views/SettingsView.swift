//
//  SettingsView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 11/22/24.
//

import SwiftUI

// todo not sure how this can be made to work totally yet
struct SettingsView: View {
    @Environment(HiLoFlipCardGame.self) var gameData
    
    var body: some View {
        @Bindable var gameData = gameData
        TextField(
            "Name for Player One",
            text: $gameData.playerNames[0]
        )
        TextField(
            "Name for Player Two",
            text: $gameData.playerNames[1]
        )
    }
}

#Preview {
    SettingsView()
}
