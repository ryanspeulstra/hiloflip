//
//  InstructionsView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 11/22/24.
//
import SwiftUI

struct InstructionsView: View {
    var body: some View {
        ZStack {
            Color(red: 0, green: 0.4666666, blue: 0).edgesIgnoringSafeArea(.all)
            VStack {
                Text("HiLo Flip").font(.title).foregroundStyle(.white).bold()
                Text("To begin each of your turns you will look at the Hi-Lo chip as well as the top card on the discard pile. The side of the Hi-Lo chip that is face-up determines what cards you can play on your turn.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("If the Hi side is face-up, you can only play a card that is higher than the number of the top card on the discard pile.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("If the Lo side is face-up, you can only play a card that is lower than the number of the top card on the discard pile.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("Should you have a card that you can play, you must play it. Your turn then ends. ").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("If you do not have a card in your hand that you can play, you will flip the Hi-Lo chip into the air. The side that lands face up determines what you will do next.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("Should the opposite side of the chip land face-up, you will pick a card from your hand to play. Your turn then ends.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("If the chip lands on the same side that it was on before, you will draw the top card from the draw pile. Look at this new card and see if you can play it based on the top card on the discard pile and the side that is face-up on the Hi-Lo chip. If you can play it, you must play it. Your turn then ends.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("Special Cards").font(.title).foregroundStyle(.white).bold()
                Text("Whenever you play a card that ends in a one, you force the next player in turn order to draw one card and add it to their hand. They also lose their next turn.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("When you play a card that ends in two, you must immediately play a second card. The one exception to this is if you have no other cards left in your hand.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
                Text("These cards have no special effect when you play them. Instead they are worth ten points each when scoring at the end of a round.").foregroundStyle(.white).font(.system(size: 15)).padding([.leading, .trailing])
            }
        }
    }
}

#Preview {
    InstructionsView()
}
