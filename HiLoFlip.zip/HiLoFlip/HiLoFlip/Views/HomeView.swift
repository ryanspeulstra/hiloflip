//
//  HomeView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 11/22/24.
//

import SwiftUI

enum GameRoute: Hashable {
    case newgame, instructions, settings
}

struct HomeView: View {
    var body: some View {
        NavigationStack {
            VStack {
                NavigationLink(value: GameRoute.newgame) {
                    Text("New Game")
                        .font(.title)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.blue)
                        .foregroundStyle(.white)
                        .cornerRadius(10)
                }

                NavigationLink(value: GameRoute.instructions) {
                    Text("Instructions")
                        .font(.title)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.blue)
                        .foregroundStyle(.white)
                        .cornerRadius(10)
                }
                NavigationLink(value: GameRoute.settings) {
                    Text("Settings")
                        .font(.title)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(.blue)
                        .foregroundStyle(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
            .navigationDestination(for: GameRoute.self) { route in
                switch route {
                case .newgame: GameView()
                    case .instructions: InstructionsView()
                    case .settings: SettingsView()
                }
            }
        }
    }
}


#Preview {
    HomeView()
}
