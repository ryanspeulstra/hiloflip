//
//  GameView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 9/13/24.
//

import SwiftUI

struct GameView: View {
    @Environment(HiLoFlipCardGame.self) var gameData
  @State private var quitOptions = false
  @Environment(\.dismiss) private var dismiss
  @State var dragOffset: CGSize = .zero
  @State var draggedCard: HiLoGame.Card?
  @GestureState var gesturePanOffset: CGSize = .zero
  @State private var discardPile: CGRect = .zero
    @State var isDragging: Int = 0
  var game = HiLoFlipCardGame(playerNames: ["Jeff", "Bob"])
    
  var body: some View {
    NavigationStack {
      ZStack {
          // background
        Color(red: 0, green: 0.4666666, blue: 0).edgesIgnoringSafeArea(.all)
          // game
        VStack {
            Text("\(game.players[(game.currentPlayer == 0) ? 1 : 0].name)").foregroundStyle(.white)
            // renders top set of cards
            cardGameView(playerIndex: (game.currentPlayer == 0) ? 1 : 0).zIndex(1)
            // renders middle token, deck, discard pile
            gameLoop
            // renders bottom set of cards
            cardGameView(playerIndex: game.currentPlayer).zIndex(1)
            Text("\(game.players[game.currentPlayer].name)").foregroundStyle(.white)
        }.navigationBarBackButtonHidden(true)
          .onAppear {
              game.resetGame()
          }.actionSheet(isPresented: $quitOptions) {
            quitGame
          }
      }
      .toolbar {
        Button("Quit") {
          quitOptions = true
        }.bold()
      }
    }
  }
    
  func cardGameView(playerIndex: Int) -> some View {
    ScrollView {
      LazyVGrid(columns: [GridItem(.adaptive(minimum: 85))]) {
          ForEach(0..<game.handSize(playerIndex), id: \.self) { index in
         //     game.players[playerIndex].hand[index].CardIndex = index // Test
          CardView(card: game.players[playerIndex].hand[index])
            .frame(width: cardWidth, height: cardHeight).gesture(
                dragCard(for: game.players[playerIndex].hand[index], CardIndex: index)
            ).offset(
              draggedCard == game.players[playerIndex].hand[index]
              && playerIndex == game.currentPlayer
                ? dragOffset : .zero)
            .zIndex(isDragging == index ? 1 : 0)
        }
        .padding(.bottom, 15)
      }
      Spacer()
    }
  }

var gameLoop: some View {
    HStack {
      Spacer()
        TokenView(isHi: game.isTokenHi).frame(width: 150, height: 150).onTapGesture {
            game.flipToken()
        }
      Spacer()
      deck.frame(width: cardWidth, height: cardHeight).onTapGesture {
    // TODO
          game.playCard(game.players[0].hand[1])
          game.swapPlayer()
      }
        Text("\(game.isTokenHi)")
        discard.frame(width: cardWidth, height: cardHeight)
      Spacer()
    }
}
    
    
  var quitGame: ActionSheet {
    ActionSheet(
      title: Text("Do you want to quit?"),
      buttons: [
        .default(Text("Exit Game")) { game.resetGame(); game.swapPlayer() },
        .default(Text("Cancel")) { dismiss() },
      ])
  }

    func dragCard(for card: HiLoGame.Card, CardIndex: Int) -> some Gesture {
    DragGesture()
    .onChanged {
      value in
      draggedCard = card
      dragOffset = value.translation
        isDragging = CardIndex
    }
    .onEnded { value in
      dragOffset = gesturePanOffset
      draggedCard = nil
        if (discardPile.contains(value.location)) {
            withAnimation {
                game.playCard(card)
            }
        }
    }
  }

  @ViewBuilder
  var discard: some View {
    if let topCard = game.topDiscardCard {
      CardView(card: topCard)
    } else {
      ZStack {
        RoundedRectangle(cornerRadius: 15)
        Text("Discard")
      }
    }
  }

  var discardTopCard: some View {
    GeometryReader { geometry in
      Color.clear
        .onAppear {
            self.discardPile = geometry.frame(in: .global)
        }
        .onChange(of: geometry.frame(in: .global)) { _, newFrame in
            self.discardPile = newFrame
        }
    }
  }
    
}


#Preview {
    GameView().environment(HiLoFlipCardGame(playerNames: ["Jeff", "Bob"]))
}
