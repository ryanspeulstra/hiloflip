//
//  GameView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 9/13/24.
//

import SwiftUI

struct GameView: View {
  @State private var quitOptions = false
  @Environment(\.dismiss) private var dismiss
  @State var dragOffset: CGSize = .zero
  @State var draggedCard: HiLoGame.Card?
  @GestureState var gesturePanOffset: CGSize = .zero
  @State private var discardPile: CGRect = .zero
    @State var isDragging: Bool = false
  var game = HiLoFlipCardGame(playerNames: ["Jeff", "Bob"])
    
  var body: some View {
    NavigationStack {
      ZStack {
        Color(red: 0, green: 0.4666666, blue: 0).edgesIgnoringSafeArea(.all)
        VStack {
          Text("\(game.players[0].name)").foregroundStyle(.white)
            cardGameView(playerIndex: game.currentPlayer + 1).zIndex(1)
            HStack {
              Spacer()
              TokenView(isHi: game.isTokenHi).frame(width: 150, height: 150)
              Spacer()
              deck.frame(width: cardWidth, height: cardHeight).onTapGesture {
                // TODO
                  game.playCard(game.players[0].hand[3])
              }
                discard.frame(width: cardWidth, height: cardHeight)
              Spacer()
            }
            cardGameView(playerIndex: game.currentPlayer).zIndex(1)
          Text("\(game.players[1].name)").foregroundStyle(.white)
        }.navigationBarBackButtonHidden(true)
          .onAppear {
              game.resetGame()
          }.actionSheet(isPresented: $quitOptions) {
            quitGame
          }
      }
      .toolbar {
        Button("Quit") {
          quitOptions = true
        }.bold()
      }
    }
  }
    
  func cardGameView(playerIndex: Int) -> some View {
    ScrollView {
      LazyVGrid(columns: [GridItem(.adaptive(minimum: 85))]) {
          ForEach(0..<game.handSize(playerIndex), id: \.self) { index in
          CardView(card: game.players[playerIndex].hand[index])
            .frame(width: cardWidth, height: cardHeight).gesture(
              dragCard(for: game.players[playerIndex].hand[index])
            ).offset(
              draggedCard == game.players[playerIndex].hand[index]
              && playerIndex == game.currentPlayer
                ? dragOffset : .zero)
            .zIndex(isDragging ? 1 : 0)
        }
        .padding(.bottom, 15)
      }
      Spacer()
    }
  }

  var quitGame: ActionSheet {
    ActionSheet(
      title: Text("Do you want to quit?"),
      buttons: [
        .default(Text("Exit Game")) { game.resetGame() },
        .default(Text("Cancel")) { dismiss() },
      ])
  }

  func dragCard(for card: HiLoGame.Card) -> some Gesture {
    DragGesture().onChanged {
      value in
      draggedCard = card
      dragOffset = value.translation
      isDragging = true
    }
    .onEnded { value in
      dragOffset = gesturePanOffset
      draggedCard = nil
        if (discardPile.contains(value.location)) {
            withAnimation {
                game.playCard(card)
            }
        }
    }
  }

  @ViewBuilder
  var discard: some View {
    if let topCard = game.topDiscardCard {
      CardView(card: topCard)
    } else {
      ZStack {
        RoundedRectangle(cornerRadius: 15)
        Text("Discard")
      }
    }
  }

  var discardTopCard: some View {
    GeometryReader { geometry in
      Color.clear
        .onAppear {
            self.discardPile = geometry.frame(in: .global)
        }
        .onChange(of: geometry.frame(in: .global)) { _, newFrame in
            self.discardPile = newFrame
        }
    }
  }
    
}


#Preview {
  GameView()
}
