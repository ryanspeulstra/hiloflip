//
//  TenPointSymbol.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 10/24/24.
//
import SwiftUI

struct TenPointSymbol: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let centerPoint = CGPoint(x: rect.midX, y: rect.midY)
        let outerRadius: CGFloat = rect.midY + 5
        let innerRadius: CGFloat = outerRadius / 2
        let startingAngle: Int = 18
        
        var starPath = Path()

        starPath.move(to: CGPoint(x: centerPoint.x + cos((Angle(degrees: Double(startingAngle))).radians) * outerRadius, y: centerPoint.x - sin(Angle(degrees: Double(startingAngle)).radians) * outerRadius))
        for i in 1..<10 {
                starPath.addLine(to: CGPoint(
                    x: centerPoint.x + cos((Angle(degrees: Double(startingAngle + i * 36))).radians) * (i % 2 == 0 ? outerRadius : innerRadius),
                    y: centerPoint.y - sin(Angle(degrees: Double(startingAngle + i * 36)).radians) * (i % 2 == 0 ? outerRadius : innerRadius))
                )
        }
        path.addPath(starPath)
        return path
    }
}

#Preview {
    TenPointSymbol().aspectRatio(contentMode: .fit)
}
