//
//  MustPlaySecondSymbol.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 10/24/24.
//
import SwiftUI

struct MustPlaySecondSymbol: Shape {

  func path(in rect: CGRect) -> Path {
    var path = Path()
      let thickness: CGFloat = rect.width * 1/7
      let gap: CGFloat = 1
      let cardHeight = rect.maxY - gap - thickness
      let cardWidth = rect.maxX - gap - thickness
      let edgeThickness = thickness/2


    let topRect = CGRect(
        x: rect.origin.x, y: rect.origin.y, width: cardWidth, height: thickness)
    path.addRoundedRect(
        in: topRect, cornerRadii: RectangleCornerRadii(topLeading: edgeThickness, topTrailing: edgeThickness))

      let leftRect = CGRect(x: rect.origin.x , y: rect.origin.y , width: thickness, height: cardHeight)
    path.addRoundedRect(
      in: leftRect, cornerRadii: RectangleCornerRadii(topLeading: edgeThickness, bottomLeading: edgeThickness))

      let midRect = CGRect(x: thickness + gap, y: thickness + gap, width: cardWidth, height: cardHeight)
      path.addRoundedRect(in: midRect, cornerSize: CGSize(width: edgeThickness, height: edgeThickness))
      
      /* Arc Code */
      path.move(to: CGPoint(x: rect.origin.x + thickness, y: rect.origin.y + thickness))
      path.addArc(center: CGPoint(x: rect.origin.x + thickness + edgeThickness, y: rect.origin.y + thickness + edgeThickness), radius: 1/25 * rect.height, startAngle: .degrees(270), endAngle: .degrees(180), clockwise: true)
    
      return path
  }
}

#Preview {
    MustPlaySecondSymbol()
}
