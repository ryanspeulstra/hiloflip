//
//  CardView.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 11/23/24.
//

import SwiftUI

let cardHeight = 140.0
let cardWidth = cardHeight - 55

// figures out from the model if it is flipped or not
struct CardView: View {
var card: HiLoGame.Card
  var body: some View {
    GeometryReader { geometry in
      ZStack {
        if card.isFaceUp {
          CardFront(setNumber: card.value)
        } else {
          CardBack()
        }
      }
    }
  }
}

// renders a card flipped over
struct CardBack: View {
var isHi: Bool = true
  var body: some View {
    ZStack {
      RoundedRectangle(cornerRadius: 15)
      VStack {
        HStack {
          TokenView(isHi: true).padding(.trailing, 23)
        }
        HStack {
          TokenView(isHi: false).padding(.leading, 23)
        }
      }
    }
  }
}


// combines all the elements into the front of the card
struct CardFront: View {
  var setNumber: Int
    var body: some View {
        ZStack {
            CardBackground
            MiddleSymbol
            HStack {
                VStack {
                    CornerSymbol.padding([.leading, .top], 5)
                    Spacer()
                }
                Spacer()
                VStack {
                    Spacer()
                    CornerSymbol.padding([.leading, .top], 5).scaleEffect(x: 1, y: -1).scaleEffect(x: -1, y: 1)
                }
            }
        }
    }
    
// renders center
  @ViewBuilder
  var MiddleSymbol: some View {
    ZStack {
      Circle().frame(width: cardWidth - 30)
      Text(String(setNumber)).foregroundStyle(.white).font(.system(size: cardWidth - 55)).fontWeight(.bold)
    }
  }

    
// renders any potential corner symbols
  @ViewBuilder
  var CornerSymbol: some View {
    ZStack {
      if setNumber % 10 == 0 {
          Circle().fill(.white).frame(width: cardWidth - 55)
          TenPointSymbol().aspectRatio(contentMode: .fit).frame(width: 19)
      } else if setNumber % 10 == 1 {
        Circle().fill(.white).frame(width: cardWidth - 55)
          SkipSymbol().stroke(lineWidth: 4).aspectRatio(contentMode: .fit).frame(width: 19)
      } else if setNumber % 10 == 2 {
        Circle().fill(.white).frame(width: cardWidth - 55)
          MustPlaySecondSymbol().aspectRatio(contentMode: .fit).frame(width: 19)
   
      }
    }
  }

// renders the card background
  @ViewBuilder
  var CardBackground: some View {
    RoundedRectangle(cornerRadius: 15)
      .fill(colorForIndex(setNumber))
      .frame(width: cardWidth, height: cardHeight)
  }
}

// renders the token
struct TokenView: View {
  var isHi: Bool
  var body: some View {
    ZStack {
      Circle()
        .fill(.black)
      Circle().inset(by: 10)
        .stroke(Color.white, lineWidth: 2)
      if isHi == true {
        Text("HI").foregroundStyle(.white).font(.system(size: 25))
      } else {
        Text("LO").foregroundStyle(.white).font(.system(size: 25))
      }
    }
  }
}

func colorForIndex(_ index: Int) -> Color {
  let hue = Double(index) / 100.0
  return Color(hue: hue, saturation: 0.8, brightness: 1)
}

var deck: some View {
        ZStack {
          RoundedRectangle(cornerRadius: 15)
          VStack {
            HStack {
              TokenView(isHi: true).padding(.trailing, 23)
            }
            HStack {
              TokenView(isHi: false).padding(.leading, 23)
            }
        }
    }
}



