//
//  SkipSymbol.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 10/24/24.
//

import SwiftUI

struct SkipSymbol: Shape {
    func path(in rect: CGRect) -> Path {
        var pathSymbol = Path()
        
        pathSymbol.addEllipse(in: rect)
        var pathLine = Path()
        let circleRadius = Double(min(rect.width, rect.height)/2)
        let circleCenter = CGPoint(x: rect.midX, y: rect.midY)
        let lineAngle = Angle(degrees: 45.0).radians
        pathLine.move(to: CGPoint(x: circleCenter.x - circleRadius * cos(lineAngle), y: circleCenter.x - circleRadius * sin(lineAngle)))
        pathLine.addLine(to: CGPoint(x: circleCenter.x + circleRadius * cos(lineAngle), y: circleCenter.x + circleRadius * sin(lineAngle)))
        
        pathSymbol.addPath(pathLine)
        return pathSymbol
    }
}


#Preview {
    GeometryReader { geometry in
        SkipSymbol().stroke(lineWidth: geometry.size.width * 0.05).aspectRatio(contentMode: .fit)
    }
}
