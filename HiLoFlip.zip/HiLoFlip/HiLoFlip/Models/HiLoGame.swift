//
//  HiLoGame.swift
//  HiLoFlip
//
//  Created by Ryan Speulstra on 9/30/24.
//

import Foundation
import SwiftUICore

struct HiLoGame {
    private(set) var deck: [Card]
    private(set) var players: [Player]
    private(set) var isTokenHi = true
    private(set) var discardPile: [Card]
    
    init(players: [String]) {
        self.deck = []
        for i in 1...100 { deck.append(Card(value: i)) }
        self.players = players.map { Player(name: $0) }
        self.discardPile = []
        dealCards()
    }
    
    private(set) var currentPlayer: Int = 0 {
        didSet {
            for playerIndex in players.indices {
                players[playerIndex].flipItems(isFaceUp: playerIndex == currentPlayer)
            }
        }
    }
        
    var playerNames: [String] {
        get { players.map { $0.name } }
        set {
            for index in 0..<newValue.count {
                players[index].name = newValue[index]
            }
        }
    }
    
    mutating func swapPlayers() {
        currentPlayer = (currentPlayer == 0) ? 1 : 0
    }
    
    
    mutating func resetGame() {
        for playersIndex in 0..<players.count {
            players[playersIndex].hand.removeAll()
        }
        discardPile.removeAll()
        dealCards()
        flipToken()
    }
    
    mutating func addCardToPlayer(_ playerIndex: Int) {
        players[playerIndex].hand.append(deck[Int.random(in: 15..<100)])
    }
    
    mutating func dealCards() {
        deck.shuffle()
        for playersIndex in 0..<players.count {
            for index in 0..<7 {
                players[playersIndex].hand.append(deck[index])
            }
            discardPile.append(deck[Int.random(in: 15..<100)])
            deck.shuffle()
        }
    }
    
    mutating func playCard(_ card: Card) {
        if (isTokenHi && discardPile.first!.value < card.value) {
            swapPlayers()
            discardPile.append(card)
            for index in players[currentPlayer].hand.indices {
                players[currentPlayer].hand.remove(at: index)
            }
        } else if (!isTokenHi && discardPile.first!.value > card.value) {
            swapPlayers()
            discardPile.append(card)
            for index in players[currentPlayer].hand.indices {
                players[currentPlayer].hand.remove(at: index)
            }
        }
    }
    
    mutating func flipToken() {
        isTokenHi ? (isTokenHi = false) : (isTokenHi = true)
    }
    
    struct Card: Equatable, Identifiable {
        let id = UUID()
        let value: Int
        fileprivate(set) var isFaceUp: Bool
        private(set) var isSpecialCard: Bool
        private(set) var isTenPointCard: Bool
        private(set) var isSkipCard: Bool
        private(set) var isMustPlaySecondCard: Bool
        
        init(value: Int) {
            self.value = value
            self.isFaceUp = true
            self.isSpecialCard = value % 10 < 2 ? true : false
            self.isTenPointCard = value % 10 == 0 ? true : false
            self.isSkipCard = value % 10 == 2 ? true : false
            self.isMustPlaySecondCard = value % 10 == 1 ? true : false
        }
        
    }   
    
    struct Player {
        fileprivate(set) var name: String
        fileprivate(set) var hand: [Card]
        private(set) var score: Int
        
        init(name: String) {
            self.name = name
            self.hand = []
            self.score = 0
        }
        mutating func flipItems(isFaceUp: Bool) {
            for index in hand.indices {
                hand[index].isFaceUp = isFaceUp
            }
        }
        
    }
    
}


